package com.mycompany.shinsato_9_2_assignment_mysqljava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Shinsato_9_2_Assignment_MySQLJava {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/databasedb";
        String user = "student1";
        String password = "pass";

        try {
            Connection conn = DriverManager.getConnection(url, user, password);

            System.out.println("Connection successful!");

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT CURRENT_USER()");

            while (rs.next()) {
                System.out.println("Logged in as: " + rs.getString(1));
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("Connection failed!");
            e.printStackTrace();
        }
    }
}